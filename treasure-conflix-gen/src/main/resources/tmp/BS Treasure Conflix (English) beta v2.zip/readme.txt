### Patch for ROM (CRC32 57A070E2)

BPS patch (beta v2): [Download](BS Treasure Conflix (English) beta v2.zip)<br/>

File/ROM SHA-1: EAECEB99FE7CAEDB01C2E137669CB05AEFB60944<br/>
File/ROM CRC32: 57A070E2<br/>
File size	1048576 ($100000)

TIPS (as nobody reads the in-game manual):

- You can use L and R in conjunction with the D-pad to turn faster while in combat.
- You can only find a treasure after you've been given the clue or the map for that treasure.
- Treasure maps can be opened from the treasure chest on the bridge.
- Selecting a city on the navigation map will add a red arrow on the compass to that location.
  You can remove the arrow by selecting "turn off navigation" on the same map.
  (This GPS feature is not really useful anyway, as the world is not that big)
- If you don't know what to do to proceed in the story, go talk to Loud.

