Apply to the following rom:

Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: EAECEB99FE7CAEDB01C2E137669CB05AEFB60944
File/ROM CRC32: 57A070E2